import React from "react";

export default function Card(){
    return(
        <div className="card">
            <img src = "../images/katie-zaferes.jpg" className="card--celebrity" />
            <div className="card--stats">
                <img src = "../images/rating-icon.jpeg" className="card--star" />
                <span> 5.0</span>
                <span className = "Gray">(6) • </span>
                <span className = "Gray">USA</span>
            </div>
            <p> Life Lessons with Katie Zaferes </p>
            <p> From $136 / person </p>
        </div>
    )
}