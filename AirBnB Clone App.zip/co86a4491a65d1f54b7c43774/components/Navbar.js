import React from "react";

export default function Navbar(){
    return (
        <nav className = "image">
            <img src="../images/airbnb.jpg" className="nav--logo"/>
        </nav>
    )
}